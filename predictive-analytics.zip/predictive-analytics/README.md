# Housing Price Predictive Analytics

A complete, leakage-free machine learning pipeline that predicts housing prices using
Linear Regression and Random Forest models, with feature importance analysis.

## What this project demonstrates

- A proper **train/test split before any preprocessing** (avoids data leakage)
- Correct use of `StandardScaler` with `.fit_transform()` on training data only,
  and `.transform()` on test data
- Baseline model (Linear Regression) vs. ensemble model (Random Forest)
- Model evaluation with RMSE, MAE, and R²
- Feature importance analysis
- Clean, modular, reusable code structure

## Project structure

```
predictive-analytics/
├── data/                     # Place your own CSV here (optional)
├── models/                   # Trained models get saved here
├── notebooks/
│   └── exploration.ipynb     # Optional space for EDA
├── src/
│   ├── data_preprocessing.py # Loading, cleaning, splitting, scaling
│   ├── train_model.py        # Model training
│   └── evaluate_model.py     # Metrics + feature importance
├── main.py                   # Runs the full pipeline end to end
├── requirements.txt
└── README.md
```

## Getting started

```bash
# 1. Clone your repo and enter it
cd predictive-analytics

# 2. Create a virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the pipeline
python main.py
```

By default this uses a bundled **synthetic housing dataset** (`data/housing_sample.csv`,
1,200 rows) with realistic, correlated features — square footage, bedrooms, bathrooms,
age, distance to city center, lot size, crime index, school rating, and garage spaces —
so it runs immediately with no downloads required.

## Using your own dataset

Drop a CSV into `data/` (e.g. `NYHousing.csv`) and update the `DATA_PATH` and
`TARGET_COLUMN` variables at the top of `main.py`:

```python
DATA_PATH = "data/NYHousing.csv"
TARGET_COLUMN = "PRICE"
```

The pipeline (splitting, scaling, training, evaluating) works the same way as long as
your target column is numeric.

## Why the split-then-scale order matters

A common mistake is fitting a scaler (or doing any transformation) on the **entire**
dataset before splitting into train/test. That leaks information about the test set's
distribution into training, which inflates accuracy in a way that won't hold up on truly
unseen data. This project always:

1. Splits the raw data first
2. Fits the scaler only on `X_train`
3. Applies that same fitted scaler to `X_test`

## Results

After running `main.py`, you'll see a printed comparison table of both models
(RMSE, MAE, R²) and a saved feature importance chart in `models/`.

| Model | RMSE | MAE | R² |
|---|---|---|---|
| Linear Regression | 24,836.87 | 20,232.80 | 0.944 |
| Random Forest | 28,731.47 | 22,786.82 | 0.925 |

### Feature Importance

<p align="center">
  <img src="models/feature_importance.png" width="600" alt="Feature Importance Chart">
</p>

## License

MIT — feel free to reuse and adapt this for your own portfolio.
