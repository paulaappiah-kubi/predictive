"""
main.py

Runs the full predictive analytics pipeline end to end:
1. Load data
2. Split (before scaling, to avoid leakage) and scale
3. Train a Linear Regression baseline and a Random Forest model
4. Evaluate both models
5. Plot feature importance for the Random Forest model
"""

import os
import pandas as pd
from src.data_preprocessing import load_data, split_and_scale
from src.train_model import train_linear_regression, train_random_forest
from src.evaluate_model import evaluate_model, plot_feature_importance

# --- Configuration ---
# To use your own CSV, set DATA_PATH to its location (e.g. "data/NYHousing.csv")
# and set TARGET_COLUMN to the name of the column you want to predict.
DATA_PATH = None          # e.g. "data/NYHousing.csv"
TARGET_COLUMN = None      # e.g. "PRICE"


def main():
    os.makedirs("models", exist_ok=True)

    print("Loading data...")
    X, y = load_data(data_path=DATA_PATH, target_column=TARGET_COLUMN)
    feature_names = list(X.columns)
    print(f"Loaded {X.shape[0]} rows, {X.shape[1]} features.")

    print("\nSplitting (train/test) BEFORE scaling to avoid data leakage...")
    X_train, X_test, y_train, y_test, scaler = split_and_scale(X, y)

    print("\nTraining models...")
    linear_model = train_linear_regression(X_train, y_train)
    forest_model = train_random_forest(X_train, y_train)

    print("\nEvaluating models...")
    results = []
    results.append(evaluate_model(linear_model, X_test, y_test, "Linear Regression"))
    results.append(evaluate_model(forest_model, X_test, y_test, "Random Forest"))

    print("\n--- Summary ---")
    results_df = pd.DataFrame(results)
    print(results_df.to_string(index=False))

    plot_feature_importance(forest_model, feature_names)


if __name__ == "__main__":
    main()
