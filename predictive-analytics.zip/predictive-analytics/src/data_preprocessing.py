"""
data_preprocessing.py

Handles loading, cleaning, splitting, and scaling data.

IMPORTANT: The split always happens BEFORE scaling to avoid data leakage.
The scaler is fit only on the training set, then applied to the test set.
"""

import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

DEFAULT_DATASET_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "housing_sample.csv")


def load_data(data_path: str = None, target_column: str = None):
    """
    Loads data either from a custom CSV (if data_path is provided) or falls
    back to the bundled sample housing dataset (data/housing_sample.csv).

    Returns:
        X (DataFrame): feature columns
        y (Series): target column
    """
    if data_path:
        df = pd.read_csv(data_path)
        df = df.dropna()
        if target_column is None:
            raise ValueError("target_column must be specified when using a custom CSV.")
        X = df.drop(columns=[target_column])
        y = df[target_column]
    else:
        df = pd.read_csv(DEFAULT_DATASET_PATH)
        df = df.dropna()
        X = df.drop(columns=["price"])
        y = df["price"]

    return X, y


def split_and_scale(X, y, test_size: float = 0.2, random_state: int = 42):
    """
    Splits data into train/test sets FIRST, then fits the scaler only on
    training data. This is the correct order to avoid data leakage.

    Returns:
        X_train_scaled, X_test_scaled, y_train, y_test, scaler
    """
    # Step 1: split raw data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    # Step 2: fit scaler on training data ONLY
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    # Step 3: apply the SAME fitted scaler to test data
    X_test_scaled = scaler.transform(X_test)

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler
