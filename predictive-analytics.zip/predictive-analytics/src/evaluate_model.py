"""
evaluate_model.py

Evaluates trained models with standard regression metrics and
plots feature importance for tree-based models.
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


def evaluate_model(model, X_test, y_test, model_name: str = "Model"):
    predictions = model.predict(X_test)

    rmse = np.sqrt(mean_squared_error(y_test, predictions))
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    print(f"\n--- {model_name} ---")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE:  {mae:.4f}")
    print(f"R²:   {r2:.4f}")

    return {"model": model_name, "rmse": rmse, "mae": mae, "r2": r2}


def plot_feature_importance(model, feature_names, output_path: str = "models/feature_importance.png"):
    """
    Plots and saves feature importance for tree-based models
    (e.g., RandomForestRegressor).
    """
    if not hasattr(model, "feature_importances_"):
        print("Model does not support feature importance plotting.")
        return

    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1]

    plt.figure(figsize=(8, 5))
    plt.title("Feature Importance")
    plt.bar(range(len(importances)), importances[indices], align="center")
    plt.xticks(range(len(importances)), [feature_names[i] for i in indices], rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"\nFeature importance chart saved to {output_path}")
